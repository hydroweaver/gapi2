let bt = document.getElementById("authAndLoadButton");
let loaderDiv = document.createElement("div");
loaderDiv.className = "loader";
document.getElementById("title").insertAdjacentElement('afterend', loaderDiv);
fetch("http://localhost:8000").then((res)=>{
  res.text().then((final)=>{
    loaderDiv.remove();
    bt.onclick = function(){
      chrome.tabs.update({url: final});
      // window.close();
    }
  });
}).catch((err)=>{
  console.log(err);
});

